import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

public class __jspPage0_Login_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		java.lang.Object __tempVar;
		response.setContentType("text/html; charset=utf-8");
		__jspPage0_Login_jsp page = this;
		HttpSession session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, -1, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n");

			out.write("\n\n");

				
    final SimpleDateFormat format = new SimpleDateFormat("ddMMMyyyy HH:mm:ss.S");
    String date = format.format(new Date());


			out.write("\n<!-- Generated at ");
			out.print(
				date
			);

			out.write(" -->\n\n<html>\n<head>\n<title>Login Page</title>\n<link href=\"/stylesheets/styles.css\" rel=\"stylesheet\" type=\"text/css\">\n</head>\n<body onload=\"document.getElementById('input_username').focus()\">\n\n<form target=\"_top\" name=\"loginForm\" method=\"post\" action=\"j_security_check");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\">\n\t<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-top:1em;\">\n\t\t<tr>\n\t\t\t<td><img src=\"/image/login_left_curve.gif\"/></td>\n\t\t\t<td><img src=\"/image/user_login.gif\"/></td>\n\t\t\t<td><img src=\"/image/login_right_curve.gif\"/></td>\n\t\t</tr>\n\n\t\t<tr>\n\t\t\t<td style=\"background: url(/image/4WotsHot_side.gif) repeat-y;\"/></td>\n\t\t\t<td style=\"padding:10px 0px\">\n\t\t\t\t<table border=\"0\">\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td class=\"h5DarkBlue\">Login </td>\n\t\t\t\t\t\t<td> <input maxlength=\"100\" id=\"input_username\" name=\"j_username\" size=\"14\" value=\"\" ></td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<td class=\"h5DarkBlue\">Password </td>\n\t\t\t\t\t\t<td> <input type=\"password\" name=\"j_password\" size=\"14\"></td>\n\t\t\t\t\t</tr>\n\t\t\t\t</table>\n\t\t\t</td>\n\t\t\t<td style=\"background: url(/image/3WotsHot_side.gif) repeat-y;\"/></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td style=\"background: url(/image/4WotsHot_side.gif) repeat-y;\"/></td>\n\t\t\t<td align=\"center\"><input type=\"image\" src=\"/image/login_button.gif\" alt=\"Log In\" width=\"70\" height=\"17\" vspace=\"0\" border=\"0\"></td>\n\t\t\t<td style=\"background: url(/image/3WotsHot_side.gif) repeat-y;\"/></td>\n\t\t</tr>\n        <tr>\n\t\t\t<td style=\"background: url(/image/1WotsHot_bot.gif) no-repeat;height:10px;\"/></td>\n\t\t\t<td style=\"background: url(/image/WotsHot_bot.gif) repeat-x;\"/></td>\n\t\t\t<td style=\"background: url(/image/3WotsHot_bot.gif) no-repeat bottom right;\"/></td>\n\t\t</tr>\n\t</table>\n</form>\n\n</body>\n\n</html>");
		}
		catch(Throwable __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}