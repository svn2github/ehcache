import num.NumberGuessBean;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

public class __jspPage0_examples_jsp_num_numguess_jsp extends com.orionserver.http.OrionHttpJspPage
{

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException
	{
		String _tempString;
		java.lang.Object __tempVar;
		response.setContentType("text/html");
		__jspPage0_examples_jsp_num_numguess_jsp page = this;
		HttpSession session = request.getSession(true);
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, -1, true);
		JspWriter out = pageContext.getOut();
		int __tempInt;
		try
		{

			out.write("<!--\n  Number Guess Game\n  Written by Jason Hunter <jasonh@kasoftware.com>, CTO, K&A Software\n  Copyright 1999, K&A Software, distributed by Sun with permission\n-->\n\n\n\n");
			num.NumberGuessBean numguess;
			synchronized(session)
			{
				numguess = (num.NumberGuessBean)session.getAttribute("numguess");
				if(numguess == null)
				{
					numguess = new num.NumberGuessBean();
					session.setAttribute("numguess", numguess);
				}
			}
			_tempString = request.getParameter("guess");
			if(_tempString != null && _tempString.length() > 0) numguess.setGuess(_tempString);

			out.write("\n\n\n<html>\n<head><title>Number Guess</title></head>\n<body bgcolor=\"white\">\n<font size=4>\n\n");

				 if (numguess.getSuccess()) { 

			out.write("\n\n  Congratulations!  You got it.\n  And after just ");
			out.print(
				numguess.getNumGuesses()
			);

			out.write(" tries.<p>\n\n  ");

				 numguess.reset(); 

			out.write("\n\n  Care to <a href=\"numguess.jsp");
	if(session != null && !request.isRequestedSessionIdFromCookie()) { out.write(";jsessionid="); out.write(session.getId()); }

			out.write("\">try again</a>?\n\n");

				 } else if (numguess.getNumGuesses() == 0) { 

			out.write("\n\n  Welcome to the Number Guess game.<p>\n\n  I'm thinking of a number between 1 and 100.<p>\n\n  <form method=get>\n  What's your guess? <input type=text name=guess>\n  <input type=submit value=\"Submit\">\n  </form>\n\n");

				 } else { 

			out.write("\n\n  Good guess, but nope.  Try <b>");
			out.print(
				numguess.getHint()
			);

			out.write("</b>.\n\n  You have made ");
			out.print(
				numguess.getNumGuesses()
			);

			out.write(" guesses.<p>\n\n  I'm thinking of a number between 1 and 100.<p>\n\n  <form method=get>\n  What's your guess? <input type=text name=guess>\n  <input type=submit value=\"Submit\">\n  </form>\n\n");

				 } 

			out.write("\n\n</font>\n</body>\n</html>\n");
		}
		catch(Throwable __jspE2)
		{
			out.clearBuffer();
			pageContext.handlePageException(__jspE2);
		}
		finally
		{
			out.close();
			JspFactory.getDefaultFactory().releasePageContext(pageContext);
		}
	}
}