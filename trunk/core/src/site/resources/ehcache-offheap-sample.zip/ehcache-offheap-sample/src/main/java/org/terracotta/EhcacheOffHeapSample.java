package org.terracotta;

import java.util.logging.ConsoleHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;

/**
 * Simple Ehcache offheap example.
 * @author Chris Dennis, Greg Luck
 */
public class EhcacheOffHeapSample {

    public static void main(String[] args) {
        System.err.println("Creating 128M off-heap cache");
        Cache cache = new Cache(new CacheConfiguration("ehcache-offheap-sample", 1000).overflowToOffHeap(true).maxMemoryOffHeap("128m"));
        CacheManager.create().addCache(cache);

        int i = 0;

        while (true) {
            cache.put(new Element(Integer.valueOf(++i), new byte[1024]));
            if (cache.getSize() != i) {
                break;
            }
        }

        System.out.println("Fitted " + cache.getSize() + " values into the cache");

    }

    private EhcacheOffHeapSample() {
    }
}
