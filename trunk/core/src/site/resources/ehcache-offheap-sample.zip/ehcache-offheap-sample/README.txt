README
======

Getting the License Key
-----------------------
The Ehcache Enterprise download kit (available here - http://www.terracotta.org/bigmemory) contains a trial license key
which must be added to activate the off-heap store.

Extract the license key and save to your filesystem.

How to Run the Sample
---------------------

1. Edit the pom.xml and change the following line to match the path to

   <argument>-Dorg.terracotta.license.path=/Users/gluck/terracotta-license.key</argument>

2. Type mvn verify to run the app. It will create an Ehcache with 128M of off-heap store.

   You can then play around with different sizes. To change the size of the off-heap store
   you need to:

   a. Edit the <argument>-XX:MaxDirectMemorySize=128M</argument> line to allocate the required amount

   b. Edit the following line in EhcacheOffHeapSample.java to use up to the allocated direct memory.

    Cache cache = new Cache(new CacheConfiguration("ehcache-offheap-sample", 1000).overflowToOffHeap(true).maxMemoryOffHeap("128m"));

